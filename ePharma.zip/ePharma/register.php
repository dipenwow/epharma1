<?php

if(empty($_SESSION))
	{		
		session_start();
		if(isset($_COOKIE["member_login"]))
		{	
			$_SESSION['username'] = $_COOKIE["member_login"];
			echo "<script>window.location='Cart.php';</script>";
			exit;
		}
	}
if(isset($_SESSION['username']))
{
	echo "<script>window.location='Cart.php';</script>"; 
	exit;
}

include 'backend/DBConnect.php';
	# code...
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

if (isset($_POST['add_client']))
{	$p = $_POST['pass'];
	$rep = $_POST['re-pass'];
	if ($p!=$rep) 
	{
		echo "<script>alert('Passwords don't match');</script>";
	}

	else
	{
		$email = $_POST['mail'];
		// Instantiation and passing `true` enables exceptions
		$mail = new PHPMailer(true);
		$otp = rand(10000,99999);

		try {
		    //Server settings
		    $mail->SMTPDebug = 0;                      // Enable verbose debug output
		    $mail->isSMTP();                                            // Send using SMTP
		    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
		    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
		    $mail->Username   = 'mailingsystem.epharma@gmail.com';                     // SMTP username
		    $mail->Password   = 'national789';                               // SMTP password
		   // $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
		    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

		    //Recipients
		    $mail->setFrom('from@example.com', 'Mailer');
		    $mail->addAddress($email, 'GAURAV');     // Add a recipient
		    //$mail->addAddress('ellen@example.com');               // Name is optional
		   // $mail->addReplyTo('info@example.com', 'Information');
		   // $mail->addCC('cc@example.com');
		   // $mail->addBCC('bcc@example.com');

		    // Attachments
		    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
		   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

		    // Content
		    $mail->isHTML(true);                                  // Set email format to HTML
		    $mail->Subject = 'Here is the subject';
		    $mail->Body    = 'This is the OTP;' . $otp;
		    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

		    $mail->send();

		    //	OTP verify
		    echo '<form method="POST">
				    <div style="width: 60%;margin-left: 20%;margin-top: 20%;z-index: 2:">
						Enter the OTP code received in <?php echo $email; ?> <br>
						<input type="text" name="otpcode" class="form-control" placeholder="Please refer your inbox"><br>
						<input type="submit" class="btn btn-danger btn-block" name="otp" value="Verify.."><br>
					</div>
					</form>';
			if (isset($_POST['otp'])) 
			{
				echo $_POST['otpcode'];
			}
			;

		} catch (Exception $e) {
		    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		}
	}
}
?>


<!DOCTYPE html>
<html><head>
	<title>Register with Us !!</title>
</head>
<body>
	<?php include 'include/navbar.php' ?>
	<form method="POST" class="container jumbotron form-group" action="" style="width: 70%;padding: 2rem;">
		<h1 style="font-family: sans-serif;" class="mt-5">Register</h1>
		<p>Please fill in this form to create an account.</p>
		<hr>
		<!--For UserName-->
		<div class="input-group">
			<label for="username" class="input-group-prepend mr-sm-3">Owner Name :<sup> *</sup></label>
			<input type="text" name="first_name" class="form-control form-control-sm mb-1" minlength="3" placeholder="First Name" required>
			<input type="text" class="form-control form-control-sm mb-1" minlength="3" placeholder="Middle Name" name="middle_name">
			<input type="text" class="form-control form-control-sm mb-1" minlength="3" placeholder="Last Name" name="last_name" required>
		</div><br>
		<div class="input-group">
			<label for="dob">Date of birth : <sup> *</sup></label>&nbsp;&nbsp;
			<input type="date" name="dob" id="dob" class="form-control form-control-sm" style="max-width: 180px;" required>
		</div><br>
		<!--For ShopName-->
		<div class="input-group mb-2">
			<label for="shopname">Your Pharmacy Shop Name : <sup> *</sup>&nbsp;&nbsp;</label>
			<input type="text" name="shopname" class="form-control form-control-sm mb-1" id="shopname" required>
		</div>
		<!--For Contact-->
		<label for="contact" class="mr-sm-3">Contact Information :<sup> *</sup></label>
		<input type="number" name="cont" class="form-control form-control-sm mb-3" min="9800000000" max="9888888888" required>
		<!--For Email-->
		<label for="email" class="mr-sm-3">Email address :</label>
		<div class="input-group input-group-sm mb-1"> 
			<input type="email" class="form-control" minlength="10" name="mail">
			<div class="input-group-append"><span class="input-group-text mb-3">Example: admin@yahoo.com</span></div>
		</div>
		<!--For Gender-->
		<label for="gender" class="mb-3">Gender : &nbsp;</label>
		<div class="custom-control custom-radio custom-control-inline">
			<input type="radio" class="custom-control-input" name="gender" id="customRadio" value="male">
			<label class="custom-control-label" for="customRadio">Male</label>
		</div>
		<div class="custom-control custom-radio custom-control-inline">
			<input type="radio" class="custom-control-input" id="customRadio2" name="gender" value="female">
			<label class="custom-control-label" for="customRadio2">Female</label>
		</div>
		<div class="custom-control custom-radio custom-control-inline">
			<input type="radio" class="custom-control-input" id="customRadio3" name="gender" value="other">
			<label class="custom-control-label" for="customRadio3">Other</label>
		</div><br>
		<select name="district" class="custom-select mb-3">
			<option disabled selected>-- District --</option>
			<option>Bagmati</option>
		</select>
		<div class="custom-file mb-3">
			<!--<input type="file" class="custom-file-input" id="photo">-->
			<label class="custom-file-label" for="photo">Upload your pharmacy license photo</label>
		</div>
		<label for="password" class="mr-sm-3">Enter password :<sup> *</sup></label>
		<input type="password" name="pass" class=" form-control form-control-sm " minlength="8" required>
		<label for="re-password" class="mr-sm-3">Re-enter password :<sup> *</sup></label>
		<input type="password" name="re-pass" class=" form-control form-control-sm " minlength="8" required>
		<br><input  type="submit" name="add_client" class="btn btn-outline-success" value="Register Now" style="float: right;">
		<p>Already have an account? <a href="loginform.php">Log In</a> .</p>
	</form>
	<?php include 'include/footer.php' ?>
</body>
<script>
	$(".custom-file-input").on("change", function() {
		var fileName = $(this).val().split("\\").pop();
		$(this).siblings(".custom-file-label").addClass("selected").html(fileName);
	});
</script>
</html>