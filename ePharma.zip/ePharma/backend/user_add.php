<?php 
if(empty($_SESSION))
  {   
    session_start();
    if(isset($_COOKIE["member_login"]))
    { 
      $_SESSION['username'] = $_COOKIE["member_login"];
      echo "<script>window.location='Cart.php';</script>";
      exit;
    }
  }

if (isset($_POST['add_user'])) {
	// echo "Nepal";exit();
	$un = $_POST['username'];
	$fn = $_POST['firstname'];
	$mn = $_POST['middlename'];
	$ln = $_POST['lastname'];
	$d = $_POST['district'];
	$e = $_POST['email'];
	$a = $_POST['address'];
	$c = $_POST['contact'];
	$p = $_POST['password'];
	$ut = $_POST['usertype'];
	$re_p = $_POST['password-re'];
	// echo 'U: '.$u.', E: '.$e.', P: '.$p;exit;
	if ($p != $re_p) 
	{
		echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	}
	else{
			$sql = "INSERT INTO `user` (`username`,`firstname`,`middlename`,`lastname`,`district`,`email`,`address`,`contact`,`password`,`usertype`) VALUES ('$un','$fn','$mn','$ln','$d','$e','$a','$c','$p','$ut')";
		require_once("DBConnect.php");
		if (mysqli_query($conn, $sql)) {
		    // echo "New record created successfully.";
		    header('Location: user_list.php');
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'include/navigation.php';?>
	<div class="container">
		<h1>Add User</h1>
		<form action="" method="POST" name="admin">
			<table class="table-sm mb-2">
				<tr>
					<td>Username : </td>
					<td><input type="text" name="username" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Full Name : </td>
					<td><input type="text" name="firstname" placeholder="Full Name" class="form-control form-control-sm" required></td>
					<td><input type="text" name="middlename" placeholder="Middle Name" class="form-control form-control-sm"></td>
					<td><input type="text" name="lastname" placeholder="Last Name" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Email : </td>
					<td><input type="email" name="email" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Address : </td>
					<td><input type="text" name="address" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>District : </td>
					<td>
						<select name="district" class="custom-select mb-3">
						<option disabled selected>--District--</option>
						<option>Kathmandu</option>
						<option>Lalitpur</option>
						<option>Bhaktapur</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>Contact : </td>
					<td><input type="number" name="contact" class="form-control form-control-sm" min="9800000000" max="9888888888" placeholder="9800000000 to 9888888888" required></td>
				</tr>
				<tr>
					<td>User Type : </td>
					<td>
						<select name="usertype" class="custom-select mb-3">
						<option disabled selected>--Buyer/Admin/SuperAdmin--</option>
						<option>SuperAdmin</option>
						<option>Admin</option>
						<option>Buyer</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>Password : </td>
					<td><input type="password" name="password" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Confirm Password : </td>
					<td><input type="password" name="password-re" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="text-center"><input type="submit" name="add_user" class="btn btn-success btn-block" value="Add"></td>
				</tr>
			</table>
		</form>
		<?php include 'include/footer.php';?>
	</div>
</body>
</html>