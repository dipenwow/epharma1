<?php
// echo $_COOKIE["member_login"];exit;
if(empty($_SESSION)) // if the session not yet started
   session_start();

if(!isset($_SESSION['username'])) { 
  echo "<script>window.location='../login.php';</script>";
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <!-- Favicon -->
  <link rel="icon" href="images/favicon.png" type="image/png">
  <style type="text/css">
    img{height: 150px;width: auto;margin-bottom: 5px;}
  </style>
</head>
<body>
  <?php include 'include/navigation.php' ?>
    <div class="container">
      <div class="jumbotron mt-5 ml-5" style="padding: 1rem 2rem;">
      <font size="6" class="text-monospace">Admin Panel</font>
    <div class="row text-center mb-3">
            <a href="user_list.php" class="col-md-2"><img src="images/9.png"><br>List Users</a>
      <a href="user_add.php" class="col-md-2"><img src="images/2.png"><br>Add User</a>
      <a href="drug_list.php" class="col-md-2"><img src="images/5.jpg"><br>List Drugs</a>
      <a href="drug_add.php" class="col-md-2"><img src="images/6.png"><br>Add Drug</a>
      <a href="product_list.php" class="col-md-2"><img src="images/7.jpg"><br>List Products</a>
      <a href="product_add.php" class="col-md-2"><img src="images/2.png"><br>Add Product</a>
    </div>
    <div class="row text-center mb-3">
      <a href="pharmacy_list.php" class="col-md-2"><img src="images/13.jpg"><br>List Pharmacy</a>
      <a href="pharmacy_add.php" class="col-md-2"><img src="images/13.jpg"><br>Add Pharmacy</a>
      <a href="category_list.php" class="col-md-2"><img src="images/13.jpg"><br>List Category</a>
      <a href="category_add.php" class="col-md-2"><img src="images/13.jpg"><br>Add Category</a>
      <a href="brand_list.php" class="col-md-2"><img src="images/13.jpg"><br>List Brands</a>
      <a href="brand_add.php" class="col-md-2"><img src="images/13.jpg"><br>Add Brand</a>
    </div>
    <div class="row text-center mb-3">
      <a href="transaction_list.php" class="col-md-2"><img src="images/13.jpg"><br>View Transactions</a>
      <a href="sales_list.php" class="col-md-2"><img src="images/13.jpg"><br>View Sales</a>
      <a href="../index.php" class="col-md-2"><img src="images/13.jpg"><br>Visit Frontend</a>
    </div>
  </div>
      <?php include 'include/footer.php' ?>
    </div>

</body>
</html>