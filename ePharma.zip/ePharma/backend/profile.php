<?php 
if (empty($_SESSION))
{
	session_start();
}
$conn = mysqli_connect("localhost","root","","epharma");
$query = "SELECT * FROM user WHERE `id`=1";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'include/navigation.php';?>
<div class="container">
	<div class="card" style="width:25%;margin-left: 37%;">
    <img class="card-img-top" src="images/profile.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title"><?php echo $row['firstname']." ".$row['middlename']." ".$row['lastname']; ?></h4>
      <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
      <a href="#" class="btn btn-primary">See Profile</a>
    </div>
  </div>
  <?php include 'include/footer.php' ?>
</div>

</body>
</html>