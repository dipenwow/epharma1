<?php
$user_id = @$_GET['id'];
if (!isset($user_id)) {
	header('Location: user_list.php');
}
require_once("DBConnect.php");
$sql = "SELECT * FROM `user` WHERE `id`='$user_id'";
$result = mysqli_query($conn, $sql);
$prev_data = mysqli_fetch_assoc($result);
if (isset($_POST['updater'])) {
	$user_id = $_GET['id'];
	// echo "$user_id";exit();
	$fn = $_POST['firstname'];
	$mn = $_POST['middlename'];
	$ln = $_POST['lastname'];
	$d = $_POST['district'];
	$e = $_POST['email'];
	$a = $_POST['address'];
	$c = $_POST['contact'];
	$p = $_POST['password'];
	$ut = $_POST['usertype'];
	$re_p = $_POST['password-re'];
if ($p != $re_p) 
	{
		echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	}
	else{
			$sql = "UPDATE `user` SET `firstname`='$fn',`middlename`='$mn',`lastname`='$ln',`district`='$d',`email`='$e', `address`='$a', `contact`='$c', `password`='$p',`usertype`='$ut', WHERE `id`='$user_id';";
			// echo $sql;exit;

		require_once("DBConnect.php");
		if (mysqli_query($conn, $sql)) {
		    // echo "Record updated successfully";
		    header('Location: user_list.php');
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
<h1>Update User #<?= $prev_data['id'];?></h1>
<form action="" method="POST" name="user">
<table class="table-sm">
	<tr>
		<td>Username : </td>
		<td><input type="text" name="username" class="form-control form-control-sm" required value="<?= $prev_data['username'];?>"></td>
	</tr>
	<tr>
		<td>Full Name : </td>
		<td><input type="text" name="firstname" class="form-control form-control-sm" required value="<?= $prev_data['firstname'];?>"></td>
		<td><input type="text" name="middlename" class="form-control form-control-sm" value="<?= $prev_data['middlename'];?>"></td>
		<td><input type="text" name="lastname" class="form-control form-control-sm" required value="<?= $prev_data['lastname'];?>"></td>
	</tr>
	<tr>
		<td>Email : </td>
		<td><input type="email" name="email" class="form-control form-control-sm" required value="<?= $prev_data['email'];?>"></td>
	</tr>
	<tr>
		<td>Address : </td>
		<td><input type="text" name="address" class="form-control form-control-sm" required value="<?= $prev_data['address'];?>"></td>
	</tr>
	<tr>
		<td>District : </td>
		<td>
			<select name="district" class="custom-select mb-3" required>
			<option <?php if ($prev_data['district']=="Kathmandu") {?> selected <?php } ?>>Kathmandu</option>
			<option <?php if ($prev_data['district']=="Lalitpur") {?> selected <?php } ?>>Lalitpur</option>
			<option <?php if ($prev_data['district']=="Bhaktapur") {?> selected <?php } ?>>Bhaktapur</option>
		</select>
		</td>
	</tr>
	<tr>
		<td>Contact : </td>
		<td><input type="number" name="contact" class="form-control form-control-sm" min="9800000000" max="9888888888" required value="<?= $prev_data['contact'];?>"></td>
	</tr>
	<tr>
		<td>User Type : </td>
		<td>
			<select name="usertype" class="custom-select mb-3" required>
			<option <?php if ($prev_data['usertype']=="SuperAdminn") {?> selected <?php } ?>>SuperAdmin</option>
			<option <?php if ($prev_data['usertype']=="Admin") {?> selected <?php } ?>>Admin</option>
			<option <?php if ($prev_data['usertype']=="Buyer") {?> selected <?php } ?>>Buyer</option>
		</select>
		</td>
	</tr>
	<tr>
		<td>Password:</td>
		<td><input type="password" name="password" class="form-control form-control-sm" required value="<?= $prev_data['password'];?>"></td>
	</tr>
	<tr>
		<td>Confirm Password:</td>
		<td><input type="password" name="password-re" class="form-control form-control-sm" required value="<?= $prev_data['password'];?>"></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="updater" class="btn btn-success btn-block mb-3" value="Update"></td>
	</tr>
</table>
</form>
	<?php include 'include/footer.php';?>
	</div>
</body>
</html>