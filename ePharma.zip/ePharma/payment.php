<?php 
session_start();
$con = mysqli_connect("localhost","root","","epharma");


?>
<!DOCTYPE html>
<html><head>
	
</head>
<body>
	<?php include 'include/navbar.php' ?>
	<?php  ?>

	<form class="container jumbotron form-group" style="width: 70%;padding: 2rem;">
		<h1 style="font-family: sans-serif;" class="mt-5">Register</h1>
		<p>Please fill in this form to pay</p>
		<hr>
		<!--For UserName-->
		<div class="input-group">
			<label for="username" class="input-group-prepend mr-sm-3">Full Name :<sup> *</sup></label>
			<input type="text" name="first_name" class="form-control form-control-sm mb-1" minlength="3" placeholder="First Name" required>
			<input type="text" class="form-control form-control-sm mb-1" minlength="3" placeholder="Middle Name" name="middle_name">
			<input type="text" class="form-control form-control-sm mb-1" minlength="3" placeholder="Last Name" name="last_name" required>
		</div><br>
		
		<!--For ShopName-->
		<div class="input-group mb-2">
			<label for="shopname">Your Pharmacy Shop Name : <sup> *</sup>&nbsp;&nbsp;</label>
			<input type="text" name="shopname" class="form-control form-control-sm mb-1" id="shopname" required>
		</div>
		<!--For Contact-->
		<label for="contact" class="mr-sm-3">Contact Information :<sup> *</sup></label>
		<input type="number" name="cont" class="form-control form-control-sm mb-3" min="9800000000" max="9888888888" required>
		<!--For Email-->
		<label for="email" class="mr-sm-3">Email address :</label>
		<div class="input-group input-group-sm mb-1"> 
			<input type="email" class="form-control" minlength="10" name="mail">
			<div class="input-group-append"><span class="input-group-text mb-3">Example: admin@yahoo.com</span></div>
		</div>
		<!--For Gender-->
		
		<select name="district" class="custom-select mb-3">
			<option disabled selected>-- District --</option>
			<option>Bagmati</option>
		</select>
		<div class="custom-file mb-3">
			<input type="file" class="custom-file-input" id="photo">
			<label class="custom-file-label" for="photo">Upload your pharmacy license photo</label>
		</div>
		<label for="password" class="mr-sm-3">Enter password :<sup> *</sup></label>
		<input type="password" name="pass" class=" form-control form-control-sm " minlength="8" required>
		<label for="re-password" class="mr-sm-3">Re-enter password :<sup> *</sup></label>
		<input type="password" name="re-pass" class=" form-control form-control-sm " minlength="8" required>
		<br>
		<p>Have a nice day</p>
	</form>
	<table class="table table-bordered">
                <tr>
                    <th width="30%">Product Name</th>
                    <th width="10%">Quantity</th>
                    <th width="13%">Price Details</th>
                    <th width="10%">Total Price</th>
                    <th width="17%">Remove Item</th>
                </tr>

                <?php 
                if(!empty($_SESSION["cart"]))
                {  
                    $total=0;
                    foreach ($_SESSION["cart"] as $key => $value) 
                    {
                    	$a= $value["item_name"];
                    	$b=$value["item_quantity"];
                    	$c= $value["product_price"];
                    	$d= ($value["item_quantity"] * $value["product_price"]);
                        ?>
                        <tr>
                            <td><?php echo $a; ?></td>
                            <td><?php echo $b; ?></td>
                            <td>$ <?php echo $c; ?></td>
                            <td>
                                $ <?php echo number_format($d, 2); ?></td>
                                <td><a href="cart.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span
                                    class="text-danger">Remove Item</span></a></td>
                                </tr>
                                <?php
                                $total = $total + $d;


                            }	
                            ?>
                            <tr>
                                <td colspan="3" align="right">Total</td>
                                <th align="right">$ <?php echo number_format($total, 2); ?></th>
                                <td> <button type="submit" name="con_pay" class="btn btn-outline-success" style="float: right;" >Continue to pay</button></td>
                            </tr>
                            <?php 
                        }	
                        ?>
                    </table>



	<?php include 'include/footer.php' ?>
</body>
<script>
	$(".custom-file-input").on("change", function() {
		var fileName = $(this).val().split("\\").pop();
		$(this).siblings(".custom-file-label").addClass("selected").html(fileName);
	});
</script>
</html>